package studio0;

public class Message {

	public static void main(String args[]) {
		System.out.println("Say hi to your group mates!");
	}
}
