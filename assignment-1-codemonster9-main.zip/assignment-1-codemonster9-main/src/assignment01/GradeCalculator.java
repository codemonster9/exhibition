package assignment01;

import support.cse131.ArgsProcessor;

public class GradeCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("w" + (0+"w")+8/2);
		
		ArgsProcessor ap = new ArgsProcessor(args);
		
		String name = ap.nextString("Name?");
		
		double averageAssignmentGrade = ap.nextDouble("Average assignment grade?");
		double weightedAssignmentGrade = (averageAssignmentGrade * 40) / 100;
		double assignmentRounded = Math.round(weightedAssignmentGrade * 100.0)/100.0;

		int extensionPoints	= ap.nextInt("How many extension points were earned?");
		double weightedExtensionPoints = (double) (extensionPoints / 40.0) * 12.0;
		double extensionRounded = Math.round(weightedExtensionPoints * 100.0)/100.0;
		
		int studiosAttended	= ap.nextInt("How many studio sessions were attended?");
		double weightedStudiosAttended = (double) (studiosAttended / 8.0) * 13.0;
		double studioRounded = Math.round(weightedStudiosAttended * 100.0)/100.0;
		
		double averageQuizGrade = ap.nextDouble("Average quiz grade?");
		double weightedAveQuizGrade = averageQuizGrade*2/100;
		double quizRounded = Math.round(weightedAveQuizGrade * 100.0)/100.0;
		
		int studioPrepsCompleted = ap.nextInt("How many pre-studio modules completed?");
		double weightedStudioPrep = (double) Math.round(studioPrepsCompleted * 2.0 / 10.0 * 100.0) / 100.0;
		
		double averageExamGrade = ap.nextDouble("Average exam grade?");
		double weightedExamGrade = Math.round(averageExamGrade * 30.0 / 100.0 * 100.0)/100.0;

		boolean courseReview = Math.random() == 0.5;
		
		double finalGrade = assignmentRounded+extensionRounded+studioRounded+quizRounded+weightedStudioPrep+weightedExamGrade;
		
		double roundedGrade = Math.round(finalGrade*100.0)/100.0 + 1.0;
	
		
		System.out.println("CSE131 Grade for: " + name + "\n");
		System.out.println("Average assignment grade: " + averageAssignmentGrade + "%");
		System.out.println("\t Weighted assignment grade (out of 40): " + assignmentRounded + "%\n");
		System.out.println("Number of extension points: " + extensionPoints);
		System.out.println("\t Weighted extension grade (out of 12): " + extensionRounded + "%\n");
		System.out.println("Number of studios attended: " + studiosAttended);
		System.out.println("\t Weighted studio grade (out of 13): " + studioRounded + "% \n");
		System.out.println("Average quiz grade: " + averageQuizGrade + "%");
		System.out.println("\t Weighted quiz grade (out of 2): " + quizRounded + "% \n");
		System.out.println("Studio preps completed: " + studioPrepsCompleted);
		System.out.println("\t Weighted studio prep grade (out of 2): " + weightedStudioPrep + "% \n");
		System.out.println("Average exam grade: " + averageExamGrade + "%");
		System.out.println("\t Weighted exam grade (out of 30): " + weightedExamGrade + "% \n");
		System.out.println("Completed course review: " + courseReview + "\n");
		System.out.println("Total Grade: " + roundedGrade + "%");
	}

}
