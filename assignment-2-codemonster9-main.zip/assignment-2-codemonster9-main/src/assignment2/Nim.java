package assignment2;

import support.cse131.ArgsProcessor;

public class Nim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArgsProcessor ap = new ArgsProcessor(args);
		int stixStart = ap.nextInt("Sticks to start?");
		int	stixPrevTurn = stixStart;

		for (int i = 0; stixPrevTurn > 0; i++) {

			if (i % 2 == 0) {
				boolean stixCheck = false;
				while (stixCheck == false) {

					int stixTaken = ap.nextInt("Sticks taken?");

					if (stixTaken > 0 && stixTaken < 3) {

						if (stixPrevTurn != 1) {
							stixPrevTurn = stixPrevTurn-stixTaken;
						}
						if (stixPrevTurn > 1 && stixPrevTurn != stixTaken) {
							System.out.println("Round " + i + ": " + stixPrevTurn + " at start human takes " + stixTaken + ", so " + stixPrevTurn + " remain");
							stixCheck = true;
						}
						else if (stixPrevTurn == 1) {
							if (stixPrevTurn == stixTaken) {
								System.out.println("Round " + i + ": " + stixPrevTurn + " at start human takes " + stixTaken + ", so " + stixPrevTurn + " remain");
								System.out.println("You win!");
								stixCheck = true;
							}
							else {
								System.out.println("invalid response");
							}
						}
						else if (stixPrevTurn == 0) {
							System.out.println("Round " + i + ": " + stixPrevTurn + " at start human takes " + stixTaken + ", so " + stixPrevTurn + " remain");
							System.out.println("You win!");
							stixCheck = true;
						}
					}
					else {
						System.out.println("invalid response");
					}
				}
			}
			else {
				int stixBeforeComputer = stixPrevTurn;
				int compTakes = (int) (Math.random()*2+1);
				compTakes += 1;

				if (stixPrevTurn < 2) {
					compTakes = 1;
				}

				stixPrevTurn = stixPrevTurn-compTakes;
				System.out.println("Round " + i + ": " + stixBeforeComputer + " at start computer takes " + compTakes + ", so " + stixPrevTurn + " remain");

				if (stixPrevTurn == 0) {
					System.out.println("Computer wins!");
				}
			}
		}
	}
}