package assignment3;

import support.cse131.ArgsProcessor;

public class BubbleSort {

	public static void main(String[] args) {
		ArgsProcessor ap = new ArgsProcessor(args);
		int arraySize = ap.nextInt("Array size:");
		int[] arrayNums = new int[arraySize];
		int[] arraySort = new int[arraySize];
		int swap;
		
		for(int i=0; i<arrayNums.length; i++) {
			arrayNums[i] = ap.nextInt("Numbers:");
			arraySort[i] = arrayNums[i];
		}
		
		for (int i=0; i<arraySort.length; i++) {
			for (int j=1; j<arraySort.length; j++) {
				if (arraySort[j-1] > arraySort[j]) {
					swap = arraySort[j-1];
					arraySort[j-1] = arraySort[j];
					arraySort[j] = swap;
				}
			}
		}
		
		System.out.print("Given values:  ");
		for(int i=0; i<arrayNums.length; i++) {
			System.out.print(arrayNums[i] + " ");
		}
		
		System.out.println();
		System.out.print("Sorted values: ");
		for(int i=0; i<arraySort.length; i++) {
			System.out.print(arraySort[i] + " ");
		}
	}

}