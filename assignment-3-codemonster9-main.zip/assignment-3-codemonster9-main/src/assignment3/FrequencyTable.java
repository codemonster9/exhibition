package assignment3;

import support.cse131.ArgsProcessor;

public class FrequencyTable {

	public static void main(String[] args) {
		ArgsProcessor ap = new ArgsProcessor(args);
		int n = ap.nextInt("limit?");
		int x = ap.nextInt("how many?");
				
		System.out.println("Frequencies for " + x + " randomly generated values between 1 and " + n);

		int[] arr = new int[x];
		int[] arrCount = new int[n];
		for (int i=0; i<arr.length; i++) {
			arr[i] = (int) (Math.random()*n+1);

			arrCount[arr[i]-1]++;
		}
		
		for (int i=0; i<n; i++) {
			System.out.println(i+1 + ": " + arrCount[i]);
		}
	
		//prints completed array
		System.out.print("\narray: ");
		for (int i=0; i<arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
}
