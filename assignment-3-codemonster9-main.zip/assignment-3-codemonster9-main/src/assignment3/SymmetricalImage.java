package assignment3;

import support.cse131.ArgsProcessor;

public class SymmetricalImage {

	public static void main(String[] args) {
		ArgsProcessor ap = new ArgsProcessor(args);
		int n = ap.nextInt("n:");
		int m = ap.nextInt("m:");

		String[][] arr = new String[n][m];
		int numRands = ((n*m)/4);

		System.out.println("A randomly generated, symmetrical " + n +  " x " + m + " image:");

		for (int i=0; i<numRands; i++) {
			int randArr1 = (int) (Math.random()*n);
			int randArr2 = (int) (Math.random()*m);

			arr[randArr1][randArr2] = "*";
			arr[randArr1][m - 1 - randArr2] = "*";
		}

		for(int i=0; i<n; i++) {
			for(int j=0; j<m; j++) {
				if (arr[i][j] == "*") {
					System.out.print(arr[i][j]);
				}
				else System.out.print(" ");
			}
			System.out.println();
		}
	}
}