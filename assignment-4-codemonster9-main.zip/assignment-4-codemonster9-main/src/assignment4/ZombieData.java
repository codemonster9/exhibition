package assignment4;

import java.awt.Color;

import edu.princeton.cs.introcs.StdDraw;
import support.cse131.ArgsProcessor;
import zombies.ZombieSimulationFiles;

public class ZombieData {

	public static void main(String[] args) throws Exception {
		// NOTE: The line below will prompt the user with a file open dialog box.
		//       The contents of the selected file will be made available via the ArgsProcessor ap.
		ArgsProcessor ap = ZombieSimulationFiles.createArgsProcessorFromFile(args);

		// TODO: 1. Read in the number of entities from the ArgsProcessor
		int  argLength = ap.nextInt();
		// TODO: 2. Create the arrays that will hold entity data
		boolean[] areZombies = new boolean[argLength];
		double[] xs = new double[argLength];
		double[] ys = new double[argLength];
		// TODO: 3. Read in all the Entity data
		for(int i=0; i<argLength;i++) {
			
			String strCheck = ap.nextString();
			
			if(strCheck.equals("Zombie")) {
				areZombies[i] = true;
			}
			xs[i] = ap.nextDouble();
			ys[i] = ap.nextDouble();
		}
		// TODO: 4. Iterate through all the data and display it using StdDraw
		int count = 0;
		
		for(int i=0; i<argLength;i++) {
			if(areZombies[i] == true) {
				StdDraw.setPenColor(Color.RED);
				StdDraw.filledCircle(xs[i], ys[i], 0.008);
			}
			else {
				StdDraw.setPenColor(Color.BLACK);
				StdDraw.filledCircle(xs[i], ys[i], 0.008);
				count++;
			}
		}
		StdDraw.text(.9, .95, (count + "/" + argLength));
 	}
}
