package practice5;

/**
 * @author Dennis Cosgrove (http://www.cse.wustl.edu/~cosgroved/)
 */
public class Circles {
//	public static ToDoReturnType isCloseEnoughToUnitCircle(ToDoParameterType x, ToDoParameterType y) {
//		//TODO
//	}

	

	public static void main(String[] args) {
		
	}
}
