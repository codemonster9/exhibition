package practice6;

import assignment6.RecursiveMethods;

/**
 * @author Dennis Cosgrove (http://www.cse.wustl.edu/~cosgroved/)
 */
public class Substitutions {
	public static void main(String[] args) {
		
	}
}
