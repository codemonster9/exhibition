package assignment7;

public class Course {
	
	private String name;
	private int credits,max,occupied;
	private Student[] roster;

	/**
	 * @param name name of course
	 * @param credits credits of course
	 * @param max capacity of course
	 */
	public Course(String name, int credits, int max) {
		this.name = name;
		this.credits = credits;
		this.max = max;
		this.occupied=0;
		roster = new Student[max];
	}
	/**
	 * @return course name
	 */
	public String getName() {
		return this.name;
	}
	/**
	 * @return number of credits
	 */
	public int getCredits() {
		return this.credits;
	}
	/**
	 * @return course capacity
	 */
	public int getCapacity() {
		return this.max;
	}
	/**
	 * @return seats remaining
	 */
	public int getSeatsRemaining() {
		return this.max-this.occupied;
	}
	/**
	 * @param new student
	 * @return if the student was added to the roster
	 */
	public boolean addStudent(Student s) {

		for(int i=0;i<roster.length;i++) {
			if(this.roster[i]==s) {
				return false;
			}
		}

		if(getSeatsRemaining()>0) {
			roster[this.occupied]=s;
			this.occupied++;
			return true;
		}
		else return false;
	}
	/**
	 * @param index index of the student
	 * @return the roster at the index
	 */
	public Student getStudentAt(int index) {
		return this.roster[index];
	}
	/**
	 * @return new roster
	 */
	public String generateRoster() {
		String list = "";
		
		for(int i=0;i<this.roster.length;i++)
			if(!(this.roster[i]==null))
				list+=", "+this.roster[i];
		return list;
	}
	/**
	 * @return average GPA in the course
	 */
	public double calculateAverageGPA() {
		double GPA = 0.0;
		int count=0;
		for(int i=0;i<roster.length;i++)
			if(roster[i]!=null) {
				GPA+=roster[i].calculateGradePointAverage();
				count++;
			}
		return GPA/count;
	}
	/**
	 *@return the course name and credits
	 */
	public String toString() {
		return this.getName()+this.getCredits();
	}
}