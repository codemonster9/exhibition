package assignment7;

public class Student {
	
	private String firstName,lastName;
	private int idNum,attCredits,passCredits;
	private double bearBucks,qualPts;
	
	/**
	 * @param firstName first name of student
	 * @param lastName last name of student
	 * @param idNum student ID number
	 */
	public Student(String firstName, String lastName, int idNum) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.idNum = idNum;
	}
		
	/**
	 * @return student full name
	 */
	public String getFullName() {
		return this.firstName + " " + this.lastName;
	}
	/**
	 * @return student ID number
	 */
	public int getId() {
		return this.idNum;
	}
	/**
	 * @param grade student grade
	 * @param credits studetn credits of the grade
	 */
	public void submitGrade(double grade, int credits) {
				
		if(grade*credits>=1.7) {
			this.passCredits+=credits;
		}
		this.attCredits+=credits;	
		this.qualPts+=grade*credits;
	}
	/**
	 * @return total attempted credits
	 */
	public int getTotalAttemptedCredits() {
		return this.attCredits;
	}
	/**
	 * @return total passing credits
	 */
	public int getTotalPassingCredits() {
		return this.passCredits;
	}
	/**
	 * @return student calculated GPA
	 */
	public double calculateGradePointAverage() {
		return qualPts/attCredits;
	}
	/**
	 * @return student class standing
	 */
	public String getClassStanding() {
		if(getTotalPassingCredits()<30) {
			return "First Year";
		}
		else if(getTotalPassingCredits()<60 && getTotalPassingCredits() >= 30) {
			return "Sophomore";
		}
		else if(getTotalPassingCredits()<90 && getTotalPassingCredits() >= 60) {
			return "Junior";
		}
		else {
			return "Senior";
		}
	}
	/**
	 * @return if student is eligible
	 */
	public boolean isEligibleForPhiBetaKappa() {
		if(attCredits>=98 && calculateGradePointAverage()>=3.6 ||
				this.attCredits>=75 && calculateGradePointAverage()>=3.8)
			return true;
		else return false;
	}
	/**
	 * @param amount balance of bearbucks adding some
	 */
	public void depositBearBucks(double amount) {
		this.bearBucks+=amount;
	}
	/**
	 * @param amount balance of bearbucks subtracting some
	 */
	public void deductBearBucks(double amount) {
		this.bearBucks-=amount;
	}
	/**
	 * @return balance of bearbucks
	 */
	public double getBearBucksBalance() {
		return this.bearBucks;
	}
	/**
	 * @return cashout of bearbucks
	 */
	public double cashOutBearBucks() {
		double pastBucks = this.bearBucks;
		this.bearBucks=0.0;
		
		if(pastBucks<=10.0)
			pastBucks=0.0;
		else
			pastBucks -= 10.0;
		
		return pastBucks;
	}
	/**
	 * @param firstName first name of parent
	 * @param other other parent
	 * @param isHyphenated if last name should be hyphenated
	 * @param id student id number
	 * @return the new student
	 */
	public Student createLegacy(String firstName, Student other, boolean isHyphenated, int id) {
		
		if(isHyphenated==true) {
			other.getFullName();
			Student legacy = new Student(firstName, this.lastName+"-"+other.lastName, id);
			legacy.bearBucks=this.cashOutBearBucks()+other.cashOutBearBucks();
			return legacy;
		}
		else {
			Student legacy = new Student(firstName, this.lastName, id);
			legacy.bearBucks=this.cashOutBearBucks()+other.cashOutBearBucks();
			return legacy;
		}
	}
	/**
	 *@return the student full name and ID number
	 */
	public String toString() {
		return getFullName()+getId();
	}
}