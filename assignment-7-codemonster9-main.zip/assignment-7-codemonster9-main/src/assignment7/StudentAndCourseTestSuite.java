package assignment7;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * @author Dennis Cosgrove (http://www.cse.wustl.edu/~cosgroved/)
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({ StudentTestSuite.class, CourseTestSuite.class })
public class StudentAndCourseTestSuite {
}
