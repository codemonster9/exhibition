package assignment9;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import assignment9.scenes.Bubbles;
import assignment9.scenes.Circle;
import assignment9.scenes.Clear;
import assignment9.scenes.Forest;
import assignment9.scenes.Leaves;
import assignment9.scenes.Sequence;
import assignment9.scenes.Square;
import edu.princeton.cs.introcs.StdDraw;
import support.cse131.ArgsProcessor;

public class SceneComposer {



	public static void main(String[] args) {

		ArgsProcessor ap = new ArgsProcessor(args);
		
		// Note: Double Buffering is enabled!  
		//       You'll need to call show() to update the screen.
		//       In most cases you'll want to call show() after you've drawn something
		StdDraw.enableDoubleBuffering();
		
		Map<String,Drawable> scene = new HashMap<>();
		
		for(int i=1;i<=100;i++) {
			scene.put("b"+i, new Bubbles(i));
			scene.put("c"+i, new Circle(Math.random(),Math.random(),Math.random()/10));
			scene.put("f"+i, new Forest(i));
			scene.put("l"+i, new Leaves(i));
			scene.put("s"+i, new Square(Math.random(),Math.random(),Math.random()/10));
		}

		List<Drawable> init = new LinkedList<>();
		init.add(scene.get("f50"));
		init.add(scene.get("b48"));
		init.add(scene.get("c26"));
		init.add(scene.get("l82"));
		Sequence s = new Sequence(init);
		scene.put("init", s);
		
		scene.get("init").draw();
		s.draw();
		StdDraw.show();
		StdDraw.pause(10);

		List<Drawable> draw = new LinkedList<>();

		while(true) {
					
			StdDraw.show();
			StdDraw.pause(10);

			String user = ap.nextString("input?");
						
			if(user.equals("clear")) {
				new Clear().draw();
			}
			if(user.equals("end")) {
				break;
			}
			if(scene.get(user)!=null) {
				StdDraw.show();
				StdDraw.pause(10);
				scene.get(user).draw();
			}
			if(user.equals("record")) {
				String name = ap.nextString("name?");
				draw = new LinkedList<>();
				while(!(user.equals("stop"))) {
					user = ap.nextString("input?");
					if(scene.get(user)!=null) {
						draw.add(scene.get(user));
						scene.get(user).draw();
					}
					StdDraw.show();
					StdDraw.pause(10);
				}
				Sequence save = new Sequence(draw);
				scene.put(name,save);
			}
		}
		
		
		//this instead?
//		for(int i=0; i<user.length();i++) {
//		if(Character.isDigit(user.charAt(i))) {
//			int num = user.charAt(i);
//			break;
//		}
//	}
//
//	if(user.charAt(0)=='f') {
//		for(int i=0;i<5;i++) {
//			Forest f = new Forest(5);
//			f.draw(); f.draw(); f.draw(); f.draw();
//			Leaves l = new Leaves(5);
//			l.draw(); l.draw();
//		}
//	}

		//
		// for demo only, remove this code and write your own to do what
		//   is needed for this assignment
//		while(true) {
//			StdDraw.show();
//			StdDraw.pause(10);
//			for (int i=0; i < 10; ++i) {
//				Forest f = new Forest(5);
//				f.draw(); f.draw(); f.draw(); f.draw();
//				Leaves l = new Leaves(5);
//				l.draw(); l.draw();
//			}
//			Bubbles b = new Bubbles(10);
//			b.draw();
//			StdDraw.show();
//			StdDraw.pause(10);
//			String resp = ap.nextString("Again?");
//			if (resp.equals("no")) {
//				break;
//			}
//			else {
//				new Clear().draw();
//			}
//		}
		//
		// end of demo code
		//
	}
}