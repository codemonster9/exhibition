package imagetransform;

import java.awt.Color;

public class ImageTransforms {
	private static int getRowCount(Color[][] pixelMatrix) {
		return pixelMatrix.length;
	}

	private static int getColCount(Color[][] pixelMatrix) {
		if(pixelMatrix.length>0) {
			return pixelMatrix[0].length;
		} else {
			return 0;
		}
	}

	public static Color[][] copy(Color[][] source) {
		int rowCount = getRowCount(source);
		int colCount = getColCount(source);
		Color[][] destination = new Color [rowCount][colCount]; // TODO: replace null with a new rowCount X colCount matrix (2D array)

			// NOTE: do NOT mutate (change) the values of the passed in source

			// TODO:
			// fill destination with values from source
			for (int i=0; i<rowCount; i++) {
				for (int j=0; j<colCount; j++) {
					destination[i][j] = source[i][j];
				}
			}
		return destination;
	}

	public static Color[][] flipHorizontal(Color[][] source) {
		int rowCount = getRowCount(source);
		int colCount = getColCount(source);
		Color[][] destination = new Color[rowCount][colCount]; // TODO: replace null with a new rowCount X colCount matrix (2D array)
		

			// NOTE: do NOT mutate (change) the values of the passed in source

			// TODO:
			// fill destination with values from source
			// but flipped horizontally
			for (int i=0; i<rowCount; i++) {
				for (int j=0; j<colCount; j++) {
					destination[i][j] = source[i][colCount-1-j];
					destination[i][colCount-1-j] = source[i][j];
				}
			}
			
		return destination;
	}

	public static Color[][] flipVertical(Color[][] source) {
		int rowCount = getRowCount(source);
		int colCount = getColCount(source);
		Color[][] destination = new Color[rowCount][colCount]; // TODO: replace null with a new rowCount X colCount matrix (2D array)
		

			// NOTE: do NOT mutate (change) the values of the passed in source

			// TODO:
			// fill destination with values from source
			// but flipped vertically
			for (int i=0; i<rowCount; i++) {
				for (int j=0; j<colCount; j++) {
					destination[i][j] = source[rowCount-1-i][j];
					destination[rowCount-1-i][j] = source[i][j];
				}
			}
		return destination;
	}

	public static Color[][] mirrorLeftOntoRight(Color[][] source) {
		int rowCount = getRowCount(source);
		int colCount = getColCount(source);
		Color[][] destination = new Color[rowCount][colCount]; // TODO: replace null with a new rowCount X colCount matrix (2D array)
		

			// NOTE: do NOT mutate (change) the values of the passed in source

			// TODO:
			// fill destination with values from source
			// but mirror the left pixels onto the right side
//		for (int i=0; i<rowCount; i++) {
//			for (int j=0; j<colCount; j++) {
//				destination[i][j] = source[i][j];
//			}
//		}
		
		Color copy;
		for (int i=0; i<rowCount; i++) {
			for (int j=0; j<colCount; j++) {
				copy = destination[i][j];
				destination[i][j] = source[i][colCount-1-j];
				destination[i][colCount-1-j] = copy;
			}
		}
		return destination;
	}

	public static Color[][] rotateRight(Color[][] source) {
		int srcRowCount = getRowCount(source);
		int srcColCount = getColCount(source);
		int dstRowCount = srcColCount; // TODO: replace -1 to the correct (rotated) value for destination
		int dstColCount = srcRowCount; // TODO: replace -1 to the correct (rotated) value for destination
		Color[][] destination = new Color[dstRowCount][dstColCount]; // TODO: replace null with a new dstRowCount X dstColCount matrix (2D array)

			// NOTE: do NOT mutate (change) the values of the passed in source

			// TODO:
			// fill destination with values from source
			// but rotate each pixel to the right
			for (int i=0; i<srcColCount; i++) {
				for (int j=0; j<srcRowCount; j++) {
					destination[i][j] = source[srcRowCount-1-j][i];
				}
			}
		return destination;
	}
}