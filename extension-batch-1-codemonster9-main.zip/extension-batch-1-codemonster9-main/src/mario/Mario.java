package mario;

import support.cse131.ArgsProcessor;

public class Mario {

	public static void main(String[] args) {

		//
		// Surprise! This part is done for you.
		// Don't change this and don't ask for any other inputs
		// or testing will fail
		//
		ArgsProcessor ap = new ArgsProcessor(args);
		int size = ap.nextInt("What size mountain do you want?");
		int pattern = ap.nextInt("What pattern (1, 2, 3, or 4)?");

		if (size < 1)
			throw new IllegalArgumentException("Size must be at least 1");
		if (pattern < 1 || pattern > 4)
			throw new IllegalArgumentException("Invalid pattern, must be 1, 2, 3, or 4.  Mario aborts");

		//
		// Create the mountain by printing to System.out
		//
		int mount = 1;
		int space = size-1;

			for(int i=0; i<size; i++) {
				
				if (pattern == 1) {
					for(int z=space; z>0; z--) {
						System.out.print(" ");
					}
					space--;

					for(int j=0; j<mount; j++) {
						System.out.print("#");
					}
					System.out.println();
					if (mount == size) {
						mount += 0;
					}
					else mount++;
				}
				
				if (pattern == 2) {
					for(int j=0; j<mount; j++) {
						System.out.print("#"); 
					}
					System.out.println();
					if (mount == size) {
						mount += 0;
					}
					else mount++;
				}
				
				if (pattern == 3) {					
					for(int z=1; z<mount; z++) {
						System.out.print(" ");
					}
					mount++;
					
					for(int j=i; j<size; j++) {
						System.out.print("#");
					}
					System.out.println();
				}
				
				if (pattern == 4) {
					for(int j=i; j<size; j++) {
						System.out.print("#");
					}
					System.out.println();
				}
		}
	}
}