package minesweeper;

import support.cse131.ArgsProcessor;

public class MineSweeper {
	public static void main(String[] args) {		
		//
		// Do not change anything between here ...
		//
		ArgsProcessor ap = new ArgsProcessor(args);
		int rows = ap.nextInt("How many columns?")+2;
		int cols = ap.nextInt("How many rows?")+2;
		double probability = ap.nextDouble("What is the probability of a mine?");
		//
		// ... and here
		//
		// Your code goes below these comments
		//
		boolean[][] field = new boolean[rows][cols];
		
		for(int i=1; i<rows-1; i++) {
			for(int j=1; j<cols-1; j++) {
				if (Math.random() < probability) {
					field[i][j] = true;
				}
			}
		}
		
		int[][] field2 = new int[rows][cols];

		for(int i=1; i<rows-1; i++) {
			for(int j=1; j<cols-1; j++) {
				int bomb = -1;
				//up
				boolean m1m1 = field[i-1][j-1];
				boolean m1m0 = field[i-1][j];
				boolean m1p1 = field[i-1][j+1];
				//sideways
				boolean m0m1 = field[i][j-1];
				boolean m0p1 = field[i][j+1];
				//down
				boolean p1p1 = field[i+1][j+1];
				boolean p1p0 = field[i+1][j];
				boolean p1m1 = field[i+1][j-1];
				
				if (m1m1 == true) {
					field2[i][j]++;
				}
				if(m1m0 == true) {
					field2[i][j]++;
				}
				if(m1p1 == true) {
					field2[i][j]++;
				}
				if(m0m1 == true) {
					field2[i][j]++;
				}
				if(m0p1 == true) {
					field2[i][j]++;
				}
				if(p1p1 == true) {
					field2[i][j]++;
				}
				if(p1p0 == true) {
					field2[i][j]++;
				}
				if(p1m1 == true) {
					field2[i][j]++;
				}
				if( field[i][j] == true) {
					field2[i][j] = bomb;
				}
			}
		}
		
		for(int i=1; i<rows-1; i++) {
			for(int j=1; j<cols-1; j++) {
				if(field[i][j] == true) {
					System.out.print(" *");
				}
				else System.out.print(" .");
			}
			System.out.print("   ");
			for(int g=1; g<cols-1; g++) {
				if(field2[i][g] == -1) {
					System.out.print(" *");
				}
				else System.out.print(" " + field2[i][g]);
			}
			System.out.println();
		}
	}
}