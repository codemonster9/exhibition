package pascal;

import support.cse131.ArgsProcessor;

public class PascalsTriangle {
	public static void main(String[] args) {
		
		ArgsProcessor ap = new ArgsProcessor(args);
		
		int N = ap.nextInt("Rows?");
		
		int[][] pascal = new int[N][N];
		
		System.out.print("       column\n       ");

		for (int r=1; r<pascal.length; r++) {
			 System.out.print(r + "  ");

			for (int c=1; c<pascal.length; c++) {

				if(c == 0 || c==r) {
					pascal[r][c] = 1;
				}
				if(r<0 || c<0 || c>r) {
					pascal[r][c] = 0;
				}
				else pascal[r][c] = pascal[r-1][c] + pascal[r-1][c-1];
				
				if (pascal[r][c] != 0) {
					System.out.print(c + "       " + pascal[r][c] + " ");
				}
			}
		}
	}
}
