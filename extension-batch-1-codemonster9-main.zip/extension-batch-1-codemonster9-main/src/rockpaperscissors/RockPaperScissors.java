package rockpaperscissors;

import support.cse131.ArgsProcessor;

public class RockPaperScissors {

	public static void main(String[] args) {
		ArgsProcessor ap = new ArgsProcessor(args);
		
		int gameCount = ap.nextInt("How many games?");
		
		int rock = 1;
		int paper = 2;
		int scissors = 3;
		
		int player1 = rock;
		int player2 = 0;
				
		int winCount1 = 0;
		int winCount2 = 0;

		for (int i = 0; i < gameCount; i++) {
			
			int x = 1;
			int j = 0;
			while(j < x) {
				if (player1 == rock) {
					player1 = paper;
					j++;
				}
				else if (player1 == paper) {
					player1 = scissors;
					j++;
				}
				else if (player1 == scissors) {
					player1 = rock;
					j++;
				}
			}
			
			player2 = (int) (Math.random()*10+3);

			if (player2 == 1) {
				player2 = rock;
			}
			else if (player2 == 2) {
				player2 = paper;
			}
			else player2 = scissors;
			
			
			if (player2 == rock && player1 == scissors || player2 == paper && player1 == rock || player2 == scissors && player1 == paper) {
				winCount2++;
			}
			else winCount1++;
		}
		if (winCount2 > winCount1) {
			System.out.println("Player 2 wins with " + winCount2 + "/" + gameCount + " games. \n" + "Player 1 loses with " + winCount1 + "/" + gameCount + " games.");
		}
		else System.out.println("Player 1 wins with " + winCount1 + "/" + gameCount + " games. \n" + "Player 2 loses with " + winCount2 + "/" + gameCount + " games.");
	}

}
