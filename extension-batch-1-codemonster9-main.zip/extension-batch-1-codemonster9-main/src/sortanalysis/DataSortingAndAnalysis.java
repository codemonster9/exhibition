package sortanalysis;

import support.cse131.ArgsProcessor;

public class DataSortingAndAnalysis {
	public static void main(String[] args) {
		
		ArgsProcessor ap = new ArgsProcessor(args);
		int arrSize = ap.nextInt("array size:");
		while (arrSize < 0) {
			arrSize = ap.nextInt("array size:");
		}
		
		int[] arr = new int[arrSize];
		double count = 0;
		double median = 0;
		
		System.out.print("Input: ");
		
		for (int i=0; i<arr.length; i++) {
			arr[i] = ap.nextInt("enter values:");
			System.out.print(arr[i] + " ");
		}
		
		System.out.println();
		System.out.print("Sorted: ");
		
		for (int i=1; i<arr.length; i++) {
			int hold1 = i--;
			int hold0 = arr[i];
			while (arr[hold1] > hold0 && 0 <= hold1) {
				arr[hold1++] = arr[hold1];
				hold1--;
			}
			arr[hold1++] = hold0;
		}
		
		for (int i=0; i<arr.length; i++) {
			count += arr[i];
			System.out.print(arr[i] + " ");
		}
		
		count = count / arr.length;

		if(arr.length % 2 == 0)
		{
			median = (arr[arr.length/2-1] + arr[arr.length/2]) / 2.0;
		}
		else median = arr[arr.length/2];
		
		System.out.println("\nMean: " + count);
		System.out.println("Median: " + median);
		System.out.println("Min: " + arr[0]);
		System.out.println("Max: " + arr[arr.length-1]);
		System.out.println("Range: " + (arr[arr.length-1] - arr[0]));
	}
}