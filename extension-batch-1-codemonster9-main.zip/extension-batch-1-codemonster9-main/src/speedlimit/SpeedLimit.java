package speedlimit;

import support.cse131.ArgsProcessor;

public class SpeedLimit {

	public static void main(String[] args) {
		ArgsProcessor ap = new ArgsProcessor(args);

		int speed = ap.nextInt("How fast were you going?");
		int limit = ap.nextInt("What was the speed limit?");
		int tenOver = limit + 10;
		int fine = 0;
		
		if (speed > limit) {
			if (speed <= tenOver) {
				fine = 100;
			}
			else {
				fine = 10*(speed-limit); 
			}
			System.out.println("You reported a speed of " + speed + " MPH for a speed limit of " + limit + " MPH.\n"
					+ "You went " + (speed-limit) + " MPH over the speed limit.\n" + "Your fine is $" + fine + ".\n");
		}
		else System.out.println("Have a nice day.");
	}

}
