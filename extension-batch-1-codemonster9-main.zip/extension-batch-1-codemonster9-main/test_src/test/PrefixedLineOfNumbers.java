package test;

/**
 * @author Dennis Cosgrove (http://www.cse.wustl.edu/~cosgroved/)
 */
public interface PrefixedLineOfNumbers extends PrefixedLine {
	NumberType getNumberType();
}
