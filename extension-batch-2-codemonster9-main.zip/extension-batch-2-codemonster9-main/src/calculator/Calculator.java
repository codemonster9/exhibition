package calculator;

import support.cse131.ArgsProcessor;

public class Calculator {
	public static void main(String[] args) {
		ArgsProcessor ap = new ArgsProcessor(args);

		String text = ap.nextString();
		
		String operator = "";
		String num1 = "";
		String num2 = "";
		
		for(int i=0; i<text.length(); i++) {
			boolean digitCheck = Character.isDigit(text.charAt(i));
			boolean spaceCheck = Character.isWhitespace(text.charAt(i));
			
			if(digitCheck == false && spaceCheck == false) {
				operator = Character.toString(text.charAt(i));
			}
			
			if(digitCheck == true && operator == "" && spaceCheck == false) {
				num1 = num1 + Character.toString(text.charAt(i));
			}
			
			if(digitCheck == true && operator != "" && spaceCheck == false) {
				num2 = num2 + Character.toString(text.charAt(i));
			}
		}
		
		int one = 0;
		int two = 0;
		
		one = Integer.parseInt(num1);
		two = Integer.parseInt(num2);
		
		if(operator.equals("*")) {
			System.out.println(one + " * " + two + " = " + one*two);
		}
		else if(operator.equals("/")) {
			System.out.println(one + " / " + two + " = " + one/two);
		}
		else if(operator.equals("+")) {
			System.out.println(one + " + " + two + " = " + (one+two));
		}
		else System.out.println(one + " - " + two + " = " + (one-two));
	}
}
