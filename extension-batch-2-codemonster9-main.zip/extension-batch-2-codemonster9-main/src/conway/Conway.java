package conway;

import support.cse131.NotYetImplementedException;

public class Conway {

	private int rows, cols;
	private boolean[][] status;
	/**
	 * Constructs a new Conway board rows X columns in size with each cell's alive
	 * status false.
	 * 
	 * @param rows the number of rows
	 * @param cols the number of columns
	 */
	public Conway(int rows, int cols) {
		this.rows = rows;
		this.cols = cols;
		status = new boolean[rows][cols];
	}

	public boolean[][] getStatus() {
		return status;
	}
	
	/**
	 * @return the number of rows
	 */
	public int getRows() {
		return this.rows;
	}

	/**
	 * @return the number of columns
	 */
	public int getColumns() {
		return this.cols;
	}

	/**
	 * Sets the current status of the cell at (row, col)
	 * 
	 * @param isAlive if true, the cell is alive; if false, the cell is dead
	 * @param row
	 * @param col
	 */
	public void setAlive(boolean isAlive, int row, int col) {
		if(isAlive) {
			this.status[row][col]=true;
		}
		else this.status[row][col]=false;
	}

	/**
	 * @param row
	 * @param col
	 * @return whether or not a cell at a specific row and column is alive.
	 *         If row or col is out of bounds, you must return false.
	 */
	public boolean isAlive(int row, int col) {
		if(row<status.length && row>=0 && col<status[0].length && col>=0) {
			if(status[row][col]==true) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Make every cell not alive
	 */
	public void clear() {
		for(int i=0;i<rows;i++)
			for(int j=0;j<cols;j++)
				status[i][j]=false;
	}

	/**
	 * Consider the 3x3 cell array that has the cell at (row, col) at its center.
	 * Let's call all cells but that center cell the neighbors of that center cell.
	 * This method returns the number of neighbors that are alive.
	 * 
	 * n n n
	 * n c n
	 * n n n
	 * 
	 * Above, if c represents the cell at (row, col), each n is
	 * a neighbor of c, according to the above definition.
	 * The result is at most 8 and at least 0.
	 * 
	 * @param row
	 * @param col
	 * @return the number of living neighbors
	 */
	public int countLivingNeighbors(int row, int col) {

		boolean[] count = new boolean[8];
		int counter = 0;
		
		count[0] = isAlive(row-1,col);
		count[1] = isAlive(row+1,col);
		count[2] = isAlive(row,col+1);
		count[3] = isAlive(row,col-1);
		count[4] = isAlive(row-1,col-1);
		count[5] = isAlive(row-1,col+1);
		count[6] = isAlive(row+1,col+1);
		count[7] = isAlive(row+1,col-1);
		
		for(int i=0;i<count.length;i++) {
			if(count[i]==true)
				counter++;
		}
		return counter;
	}

	/**
	 * Executes a generation of life. Be sure to read the specification
	 * for this assignment, because it points out a common mistake students
	 * make when implementing this method.
	 * 
	 */
	public void step() {
		
		boolean[][] copy = new boolean[rows][cols];
		
		for(int i=0;i<rows;i++) {
			for(int j=0;j<cols;j++) {
				if(isAlive(i,j)==true) {
					copy[i][j]=true;
				}
				else copy[i][j]=false;
			}
		}
		for(int i=0;i<rows;i++) {
			for(int j=0;j<cols;j++) {
				if(countLivingNeighbors(i,j)<2 || countLivingNeighbors(i,j)>3) {
					copy[i][j]=false;
				}
				if(countLivingNeighbors(i,j)==3) {
					copy[i][j]=true;
				}
			}
		}
		status = copy;
	}
}