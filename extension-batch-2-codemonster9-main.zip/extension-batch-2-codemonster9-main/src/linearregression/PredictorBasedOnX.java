package linearregression;

/**
 * @author Dennis Cosgrove (http://www.cse.wustl.edu/~cosgroved/)
 */
public interface PredictorBasedOnX {
	public double predict(double x);
}
