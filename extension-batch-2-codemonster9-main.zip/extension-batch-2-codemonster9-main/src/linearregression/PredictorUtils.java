package linearregression;

import java.util.List;

import support.cse131.NotYetImplementedException;

public class PredictorUtils {
	/**
	 * @param points the points to be fed to the RegressionLine
	 * @return the new predictor
	 */
	public static PredictorBasedOnX learnPredictor(List<XY> points) {

		// Delete the line below and implement this method
		throw new NotYetImplementedException();

	}
}
