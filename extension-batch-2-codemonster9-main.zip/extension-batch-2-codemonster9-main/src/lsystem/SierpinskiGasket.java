package lsystem;

import static edu.wustl.cse.mosaic.Mosaics.above;
import static edu.wustl.cse.mosaic.Mosaics.beside;
import static edu.wustl.cse.mosaic.Mosaics.filledEquilateralTriangle;
import static edu.wustl.cse.mosaic.Mosaics.showCentered;

import edu.wustl.cse.mosaic.Mosaic;
import support.cse131.NotYetImplementedException;

/**
 * @author Dennis Cosgrove (http://www.cse.wustl.edu/~cosgroved/)
 */
public class SierpinskiGasket {
	public static Mosaic gasket(double sideLength) {
		
			// Delete the line below and implement this method
			throw new NotYetImplementedException();
		
	}

	public static void main(String[] args) {
		showCentered(gasket(1.0), 0.9);
	}
}
