package studio2;

import support.cse131.ArgsProcessor;

public class Ruin {

	public static void main(String[] args) {
		ArgsProcessor ap = new ArgsProcessor(args);
		double startAmount = ap.nextDouble("Enter the amount of money that you start with: ");
		double winChance = ap.nextDouble("Enter the win probabilty (between 0.0 and 1.0): ");
		double winLimit = ap.nextDouble("Enter the money limit: ");
		int totalSimulations = ap.nextInt("Enter number of days: ");
		int plays = 0;
		double currentAmount = startAmount;
		double ruin = 0;
		for (int i = 0; i< totalSimulations; i++) {
			while ((currentAmount > 0) && (currentAmount < winLimit)) {
				if (Math.random() <= winChance) {
					currentAmount = currentAmount+1;
				}
				else {
					currentAmount = currentAmount-1;
				}
				plays++;
				//System.out.println("Current Amount: "+currentAmount);
			}
			System.out.print("Simulation " + i+": "+plays);
			if (currentAmount ==  winLimit) {
				System.out.println(" WIN");
			}
			else {
				System.out.println(" LOSE");
				ruin++;
			}
			plays = 0;
			currentAmount = startAmount;
		}
		double expectedRuin = 0;
		if (winChance == 0.5) {
			expectedRuin = 1-(startAmount/winLimit);
		}
		else {
			double a = (1-winChance)/winChance;
			expectedRuin = (Math.pow(a,startAmount)- Math.pow(a, winLimit))/(1-Math.pow(a, winLimit));
			
		}
		System.out.println("Loses: "+ruin + "Simulations: "+ totalSimulations);
		System.out.println("Ruin Rate from Simulation: " +(double)(ruin/totalSimulations) + "Expected Ruin Rate: "+ expectedRuin);
		
	}
}
	
