package studio1;

import support.cse131.ArgsProcessor;

public class Average {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArgsProcessor ap = new ArgsProcessor(args);
		int n1 = ap.nextInt("Input first number to be averaged");
		int n2 = ap.nextInt("Input second number to be averaged");
		double intAverage =  (double) (n1 + n2) / 2;
		System.out.println("Average of " + n1 + " and " + n2 + " is " + intAverage + ".");
	}

}
