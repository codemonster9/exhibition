package support.cse131;

import support.cse131.ArgsProcessor;

public class Ruin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArgsProcessor ap = new ArgsProcessor(args);
		
		int startAmount = ap.nextInt("How much are you starting with?");
		double winChance = ap.nextDouble("What is your win chance?");
		int winLimit = ap.nextInt("What is your win limit?");
		int totalSimulations = ap.nextInt("How many days?");

		int startPrime = startAmount;
		double winPrime = winChance;
		int limitPrime = winLimit;
		
		int totalLoses = 0;

		for (int i = 1; i <= totalSimulations; i++) {

			startAmount = startPrime;
			winChance = winPrime;
			winLimit = limitPrime;
						
			int ratio = 0;

			while (startAmount != winLimit && startAmount != 0) {
								
				if (Math.random() < winChance) {
					startAmount++;
					ratio++;
				}
				else {
					startAmount--;
					ratio++;
				}
				
				if (startAmount == 0) {
					System.out.println("Simulation " + i + ": " + ratio + " LOSE");
					totalLoses++;
				}
				else if (startAmount == winLimit) {
					System.out.println("Simulation " + i + ": " + ratio + " WIN");
				}
			}
		}
		double percentage = Math.round(((double) totalLoses / totalSimulations)*100.00)/100.00;
		double expectedRuin = 0;
		
		if (winChance == 0.5) {
			expectedRuin = 1 - (startAmount/winLimit);
		}
		else {
			int alpha = ((1-winChance)/winChance);
			(Math.Pow(alpha, startAmount) - Math.pow(alpha, winLimit)) / (1- Math.pow(alpha, winLimit));
		}
		
		System.out.println("Losses: " + totalLoses + " Simulations: " + totalSimulations);
		System.out.println("Ruin Rate from Simulation: " + percentage + " Expected Ruin Rate: " + );
	}
}
