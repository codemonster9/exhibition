import support.cse131.ArgsProcessor;

public class Sieve {

	public static void main(String[] args) {
		ArgsProcessor ap = new ArgsProcessor(args);
		int n = ap.nextInt("how many numbers?");
		
		boolean[] sieve = new boolean[n];
		
		for (int i=2; i<sieve.length; i++) {
			for (int j=2; j<sieve.length; Math.pow(i,2)+j*j) {
					sieve[i*j] = true;
			}
			if (sieve[i] = false) {
				System.out.print("prime nums: " + sieve[i] + " ");
			}
		}
	}
}
