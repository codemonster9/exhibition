package studio4;

import java.awt.Color;

import edu.princeton.cs.introcs.StdDraw;

public class Flag {
	public static void main(String[] args) {
		StdDraw.setPenColor(0, 150, 0);
		StdDraw.filledRectangle(0.5, 0.5, 0.5, 0.5);
		StdDraw.setPenColor(150, 0, 0);
		StdDraw.filledEllipse(0.5, 0.3, 0.35, 0.2);
		StdDraw.setPenColor(0, 150, 0);
		StdDraw.filledRectangle(0.5, 0.4, 0.35, 0.1);
		
		StdDraw.setPenColor(Color.BLACK);
		StdDraw.filledRectangle(0.5, 0.8, 0.05, 0.1);
		
		StdDraw.setPenColor(Color.WHITE);
		StdDraw.filledEllipse(0.2, 0.8, 0.075, 0.05);
		StdDraw.filledEllipse(0.8, 0.8, 0.075, 0.05);

		
	}
}