package studio4;

import java.io.FileNotFoundException;

import javax.swing.SwingUtilities;

import edu.princeton.cs.introcs.StdDraw;
import support.cse131.ArgsProcessor;

/**
 * @author Dennis Cosgrove (http://www.cse.wustl.edu/~cosgroved/)
 */
public class InterpretDrawingFile {
	public static void readFileViaArgsProcessorAndDraw(ArgsProcessor ap) {
		String shapeType = ap.nextString();
		
		int R = ap.nextInt();
		int G = ap.nextInt();
		int B = ap.nextInt();
		StdDraw.setPenColor(R, G, B);
		
		boolean isFilled = ap.nextBoolean();
		
		
		if (shapeType.equals("rectangle")) {
			double x = ap.nextDouble();
			double y = ap.nextDouble();
			double halfWidth = ap.nextDouble();
			double halfHeight = ap.nextDouble();
			if (isFilled) {
				StdDraw.filledRectangle(x, y, halfWidth, halfHeight);
			}
			else {
				StdDraw.rectangle(x, y, halfWidth, halfHeight);
			}
		}
		
		if (shapeType.equals("triangle")) {
			double [] xs = new double [3];
			double [] ys = new double [3];
			xs[0] = ap.nextDouble();
			ys[0] = ap.nextDouble();
			xs[1] = ap.nextDouble();
			ys[1] = ap.nextDouble();
			xs[2] = ap.nextDouble();
			ys[2] = ap.nextDouble();
			if (isFilled) {
				StdDraw.filledPolygon(xs, ys);
			}
			else {
				StdDraw.polygon(xs, ys);
			}
		}
		
		if (shapeType.equals("ellipse")) {
			double x = ap.nextDouble();
			double y = ap.nextDouble();
			double semiMajorAxis = ap.nextDouble();
			double semiMinorAxis = ap.nextDouble();
			if (isFilled) {
				StdDraw.filledEllipse(x, y, semiMajorAxis, semiMinorAxis);
			}
			else {
				StdDraw.ellipse(x, y, semiMajorAxis, semiMinorAxis);
			}
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		SwingUtilities.invokeLater(()->{
			ArgsProcessor ap = DrawingFiles.createArgsProcessorFromFile(args);
			while (ap != null) {
				StdDraw.clear();
				readFileViaArgsProcessorAndDraw(ap);
				ap = DrawingFiles.createArgsProcessorFromFile(new String[] {});
			}
			System.exit(0);
		});
	}
}
