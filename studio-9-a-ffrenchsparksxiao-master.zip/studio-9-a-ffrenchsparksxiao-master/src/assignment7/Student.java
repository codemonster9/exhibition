package assignment7;

public class Student {
	
	private String firstName;
	private String lastName;
	private int idNumber;
	private double bearBucksBalance;
	private int attemptedCredits;
	private int passingCredits;
	private double totalGradeQualityPoints;
	private String classStanding;
	private double gradePointAverage;
	
	/**
	 * initializes the variables
	 * @param firstName
	 * @param lastName
	 * @param idNumber
	 */
	public Student (String firstName, String lastName, int idNumber) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.idNumber = idNumber;
		bearBucksBalance = 0;
		attemptedCredits = 0;
		passingCredits = 0;
		totalGradeQualityPoints = 0;
	}
	
	/**
	 * initializes first name
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * initializes last name
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	/**
	 * initializes ID Number
	 * @param idNumber
	 */
	public void setIdNumber(int idNumber) {
		this.idNumber = idNumber;
	}
	
	/**
	 * accesses the full name by combining the first and last names of the Student
	 * @return
	 */
	public String getFullName() {
		return this.firstName + " " + this.lastName;
	}
	
	/**
	 * accesses the ID Number
	 * @return
	 */
	public int getId() {
		return this.idNumber;
	}
	
	/**
	 * calculates the quality points  
	 * @param grade
	 * @param credits
	 */
	public void submitGrade(double grade, int credits) {
		totalGradeQualityPoints += (credits*grade);
		attemptedCredits += credits;
		
		if (grade >= 1.7){
			passingCredits += credits;
		}
	}
	
	/**
	 * returns number of attempted credits
	 * @return
	 */
	public int getTotalAttemptedCredits() {
		return attemptedCredits;
	}
	
	/**
	 * returns number of passing credits
	 * @return
	 */
	public int getTotalPassingCredits() {
		return passingCredits;
	}
	
	/**
	 * takes in the number of quality points and divides by attempted credits to find GPA; returns GPA
	 * @return
	 */
	public double calculateGradePointAverage() {
		gradePointAverage = totalGradeQualityPoints/attemptedCredits;
		return gradePointAverage;
	}
	
	/**
	 *  takes in the number of passing credits and evaluates what class that student is in
	 * @return
	 */
	public String getClassStanding() {
		if (passingCredits < 30) {
			classStanding = "First Year";
		}
		else if (passingCredits >= 30 && passingCredits < 60) {
			classStanding = "Sophomore";
		}
		else if (passingCredits >= 60 && passingCredits < 90) {
			classStanding = "Junior";
		}
		else {
			classStanding = "Senior";
		}
		return classStanding;
	}
	
	/**
	 * takes in number of passing credits and GPA to determine eligibility to join fraternity
	 * @return
	 */
	public boolean isEligibleForPhiBetaKappa() {
		if (passingCredits >= 98 && calculateGradePointAverage() >= 3.60) {
			return true;
		}
		else if (passingCredits >= 75 && calculateGradePointAverage() >= 3.80) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * takes in the amount and adds to total Bear Bucks Balance
	 * @param amount
	 */
	public void depositBearBucks(double amount) {
		bearBucksBalance += amount;
	}
	
	/**
	 * takes in amount and deducts from Bear Bucks Balance
	 * @param amount
	 */
	public void deductBearBucks(double amount) {
		bearBucksBalance -= amount;
	}
	
	
	/**
	 * returns Bear Bucks Balance
	 * @return
	 */
	public double getBearBucksBalance() {
		return bearBucksBalance;
	}
	
	/**
	 * applies WashU's old policy to refund the student the remaining balance of Bear Bucks
	 * @return
	 */
	public double cashOutBearBucks() {
		if (bearBucksBalance < 10) {
			bearBucksBalance = 0;
			return 0;
		}
		else {
			double tempBearBucks = bearBucksBalance;
			bearBucksBalance = 0;
			return tempBearBucks - 10;
		}
	}
	
	/**
	 * takes in original student's name and new student's name and the original id to make the legacy student
	 * @param firstName
	 * @param other
	 * @param isHyphenated
	 * @param id
	 * @return
	 */
	public Student createLegacy(String firstName, Student other, boolean isHyphenated, int id) {
		String legacyLastName = "";
		if (isHyphenated) {
			legacyLastName = lastName + "-" + other.lastName;
		}
		else {
			legacyLastName = lastName;
		}
		
		Student legacyStudent = new Student(firstName, legacyLastName, id);
		legacyStudent.depositBearBucks(this.cashOutBearBucks() + other.cashOutBearBucks());
		return legacyStudent;
	}
	
	/**
	 * returns the full name and id number of string
	 */
	public String toString() {
		return this.getFullName() + " " + this.getId();
	}
	
}