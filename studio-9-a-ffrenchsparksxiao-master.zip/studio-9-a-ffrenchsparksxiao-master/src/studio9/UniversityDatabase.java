package studio9;

import java.util.HashMap;
import assignment7.Student;

public class UniversityDatabase {
	private final HashMap<String, Student> mapStudent;
	
	public UniversityDatabase() {
		this.mapStudent = new HashMap<>();
	}
		
	public void addStudent(String accountName, Student student) {
		mapStudent.put(accountName,student);
	}

	public int getStudentCount() {
		return mapStudent.size();
	}

	public String lookupFullName(String accountName) {
		if(mapStudent.get(accountName).getFullName()!=null)
			return mapStudent.get(accountName).getFullName();
		else return null;
	}

	public double getTotalBearBucks() {
		mapStudent.keySet(getTotalBearbucks());
	}
}
